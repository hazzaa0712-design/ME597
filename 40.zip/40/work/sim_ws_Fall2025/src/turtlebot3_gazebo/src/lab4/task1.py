#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import PoseWithCovarianceStamped
import numpy as np
import math
import random

class Task1(Node):
    """
    Environment mapping task using improved wall-following and escape strategies.
    """
    def __init__(self):
        super().__init__('task1_node')

        # Publishers and subscribers
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.scan_sub = self.create_subscription(LaserScan, '/scan', self.scan_callback, 10)
        self.map_sub = self.create_subscription(OccupancyGrid, '/map', self.map_callback, 10)

        # Timer for control loop
        self.timer = self.create_timer(0.1, self.timer_cb)

        # Robot state variables
        self.scan_data = None
        self.map_data = None
        self.exploration_state = 'explore'  # States: 'explore', 'escape', 'doorway'
        self.state_time = 0
        self.turn_direction = 1  # 1 for left, -1 for right

        # Wall following parameters
        self.wall_distance = 0.5  # Increased for better maneuverability
        self.min_front_distance = 0.6
        self.linear_speed = 0.35  # Slightly faster
        self.angular_speed = 0.6

        # Stuck detection
        self.stuck_counter = 0
        self.max_stuck_count = 100  # ~10 seconds
        self.similar_scan_count = 0
        self.last_scan_signature = None

        # Escape behavior
        self.escape_mode = False
        self.escape_counter = 0
        self.escape_direction = 1

        # Doorway detection
        self.doorway_detected = False
        self.doorway_counter = 0

        # Random exploration
        self.random_turn_prob = 0.08  # Increased randomness
        self.exploration_time = 0

        # Direction preference (to encourage systematic coverage)
        self.preferred_turn = 1
        self.turn_consistency_counter = 0

        self.get_logger().info('Task1 improved autonomous mapping node initialized.')

    def scan_callback(self, msg):
        """Process laser scan data."""
        self.scan_data = msg

        # Detect if stuck by comparing scan signatures
        if self.scan_data and len(self.scan_data.ranges) > 0:
            ranges = np.array(self.scan_data.ranges)
            ranges[np.isinf(ranges)] = 10.0
            ranges[np.isnan(ranges)] = 10.0

            # Create a simple signature (histogram of distances)
            signature = tuple(np.histogram(ranges, bins=10, range=(0, 5))[0])

            if self.last_scan_signature is not None:
                # Compare with last signature
                diff = sum(abs(a - b) for a, b in zip(signature, self.last_scan_signature))
                if diff < 50:  # Very similar scans
                    self.similar_scan_count += 1
                else:
                    self.similar_scan_count = 0

            self.last_scan_signature = signature

    def map_callback(self, msg):
        """Store map data."""
        self.map_data = msg

    def get_scan_regions(self):
        """Divide laser scan into regions with better resolution."""
        if self.scan_data is None or len(self.scan_data.ranges) == 0:
            return None

        ranges = np.array(self.scan_data.ranges)
        ranges[np.isinf(ranges)] = self.scan_data.range_max
        ranges[np.isnan(ranges)] = self.scan_data.range_max

        # More detailed region division
        num_points = len(ranges)
        regions = {
            'front': min(min(ranges[0:25]), min(ranges[-25:])) if len(ranges) > 50 else min(ranges[0:15]),
            'front_left': min(ranges[25:50]) if len(ranges) > 100 else min(ranges[15:30]),
            'front_right': min(ranges[-50:-25]) if len(ranges) > 100 else min(ranges[-30:-15]),
            'left': min(ranges[50:110]) if len(ranges) > 200 else min(ranges[30:60]),
            'right': min(ranges[-110:-50]) if len(ranges) > 200 else min(ranges[-60:-30]),
            'back_left': min(ranges[110:160]) if len(ranges) > 200 else 5.0,
            'back_right': min(ranges[-160:-110]) if len(ranges) > 200 else 5.0,
            'back': min(ranges[160:200]) if len(ranges) > 200 else 5.0
        }

        return regions

    def detect_doorway(self, regions):
        """Detect doorway or opening."""
        # Doorway: narrow opening with walls on sides
        if (regions['front'] > 1.0 and
            regions['front_left'] < 0.8 and
            regions['front_right'] < 0.8):
            return True

        # Another pattern: sudden opening
        if (regions['front'] > 1.5 and
            min(regions['left'], regions['right']) < 0.6):
            return True

        return False

    def escape_behavior(self):
        """Aggressive escape behavior when stuck."""
        cmd_vel = Twist()

        self.escape_counter += 1

        if self.escape_counter < 20:
            # Phase 1: Back up
            cmd_vel.linear.x = -0.15
            cmd_vel.angular.z = 0.0
        elif self.escape_counter < 50:
            # Phase 2: Rotate 180 degrees
            cmd_vel.linear.x = 0.0
            cmd_vel.angular.z = self.escape_direction * self.angular_speed * 1.5
        elif self.escape_counter < 80:
            # Phase 3: Drive forward aggressively
            cmd_vel.linear.x = self.linear_speed * 1.3
            cmd_vel.angular.z = 0.0
        else:
            # Exit escape mode
            self.escape_mode = False
            self.escape_counter = 0
            self.similar_scan_count = 0
            self.escape_direction *= -1  # Alternate direction next time

        return cmd_vel

    def doorway_behavior(self, regions):
        """Special behavior for passing through doorways."""
        cmd_vel = Twist()

        # Align with doorway
        left_dist = regions['front_left']
        right_dist = regions['front_right']

        # Center in doorway
        error = left_dist - right_dist

        cmd_vel.linear.x = self.linear_speed * 0.7
        cmd_vel.angular.z = 0.5 * error  # P-controller to center

        self.doorway_counter += 1
        if self.doorway_counter > 30:  # ~3 seconds
            self.doorway_detected = False
            self.doorway_counter = 0

        return cmd_vel

    def wall_follow_control(self, regions):
        """Improved wall-following behavior."""
        cmd_vel = Twist()

        # Emergency obstacle avoidance
        if regions['front'] < 0.35:
            cmd_vel.linear.x = -0.1
            cmd_vel.angular.z = self.angular_speed * 2.0 * self.turn_direction
            self.stuck_counter += 1
            return cmd_vel

        # Front obstacle - turn
        if regions['front'] < self.min_front_distance:
            cmd_vel.linear.x = 0.0

            # Choose turn direction based on clearance
            if regions['left'] > regions['right']:
                cmd_vel.angular.z = self.angular_speed * 1.2
                self.preferred_turn = 1
            else:
                cmd_vel.angular.z = -self.angular_speed * 1.2
                self.preferred_turn = -1

            self.stuck_counter += 1
            return cmd_vel

        # Open space - explore forward
        if all(v > 2.0 for v in [regions['front'], regions['left'], regions['right']]):
            cmd_vel.linear.x = self.linear_speed * 1.2

            # Add slight random turning
            if random.random() < self.random_turn_prob:
                cmd_vel.angular.z = random.uniform(-0.3, 0.3)
            else:
                cmd_vel.angular.z = 0.0

            self.stuck_counter = 0
            return cmd_vel

        # Wall following logic
        left_dist = regions['left']
        right_dist = regions['right']

        # Prefer following closer wall
        if left_dist < right_dist:
            # Follow left wall
            error = self.wall_distance - left_dist
            cmd_vel.angular.z = -error * 1.2  # P-controller

            # Adjust if too close
            if left_dist < self.wall_distance * 0.7:
                cmd_vel.angular.z = -self.angular_speed * 0.8

        else:
            # Follow right wall
            error = self.wall_distance - right_dist
            cmd_vel.angular.z = error * 1.2

            # Adjust if too close
            if right_dist < self.wall_distance * 0.7:
                cmd_vel.angular.z = self.angular_speed * 0.8

        # Set forward speed based on clearance
        if regions['front'] > 1.5:
            cmd_vel.linear.x = self.linear_speed * 1.1
        elif regions['front'] > 1.0:
            cmd_vel.linear.x = self.linear_speed
        else:
            cmd_vel.linear.x = self.linear_speed * 0.6

        # Clip angular velocity
        cmd_vel.angular.z = np.clip(cmd_vel.angular.z, -self.angular_speed, self.angular_speed)

        self.stuck_counter = max(0, self.stuck_counter - 1)

        return cmd_vel

    def timer_cb(self):
        """Main control loop with improved stuck detection."""
        if self.scan_data is None:
            self.get_logger().info('Waiting for scan data...', throttle_duration_sec=2)
            return

        regions = self.get_scan_regions()
        if regions is None:
            return

        cmd_vel = Twist()

        # Check if stuck (similar scans for extended period)
        if self.similar_scan_count > 80 or self.stuck_counter > self.max_stuck_count:
            if not self.escape_mode:
                self.get_logger().info('STUCK DETECTED! Initiating escape behavior.')
                self.escape_mode = True
                self.escape_counter = 0
                self.stuck_counter = 0

        # Execute escape behavior if in escape mode
        if self.escape_mode:
            cmd_vel = self.escape_behavior()

        # Check for doorway
        elif self.detect_doorway(regions):
            if not self.doorway_detected:
                self.get_logger().info('Doorway detected! Careful navigation.')
                self.doorway_detected = True
                self.doorway_counter = 0
            cmd_vel = self.doorway_behavior(regions)

        # Normal exploration
        else:
            cmd_vel = self.wall_follow_control(regions)

        # Publish velocity
        self.cmd_vel_pub.publish(cmd_vel)

        # Periodic logging
        self.state_time += 1
        if self.state_time % 50 == 0:
            status = "ESCAPE" if self.escape_mode else "DOORWAY" if self.doorway_detected else "EXPLORE"
            self.get_logger().info(
                f'[{status}] Front: {regions["front"]:.2f}, Left: {regions["left"]:.2f}, '
                f'Right: {regions["right"]:.2f}, Stuck: {self.stuck_counter}, Similar: {self.similar_scan_count}'
            )


def main(args=None):
    rclpy.init(args=args)

    task1 = Task1()

    try:
        rclpy.spin(task1)
    except KeyboardInterrupt:
        pass
    finally:
        # Stop the robot
        cmd_vel = Twist()
        cmd_vel.linear.x = 0.0
        cmd_vel.angular.z = 0.0
        task1.cmd_vel_pub.publish(cmd_vel)

        task1.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
