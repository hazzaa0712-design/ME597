#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, PoseWithCovarianceStamped, Twist
from nav_msgs.msg import OccupancyGrid, Path
from sensor_msgs.msg import LaserScan
import numpy as np
import math
import heapq
import random


class RRTStarNode:
    """Node for RRT* tree."""
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.parent = None
        self.cost = 0.0


class Task2Bonus(Node):
    """
    Navigation with A* global planning and RRT* local replanning.
    """
    def __init__(self):
        super().__init__('task2_node')

        # Subscribers
        self.goal_sub = self.create_subscription(
            PoseStamped, '/move_base_simple/goal', self.goal_callback, 10
        )
        self.pose_sub = self.create_subscription(
            PoseWithCovarianceStamped, '/amcl_pose', self.pose_callback, 10
        )
        self.map_sub = self.create_subscription(
            OccupancyGrid, '/map', self.map_callback, 10
        )
        self.scan_sub = self.create_subscription(
            LaserScan, '/scan', self.scan_callback, 10
        )

        # Publishers
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.path_pub = self.create_publisher(Path, '/global_plan', 10)
        self.local_path_pub = self.create_publisher(Path, '/local_plan', 10)

        # Control timer
        self.timer = self.create_timer(0.1, self.timer_cb)

        # State variables
        self.current_pose = None
        self.goal_pose = None
        self.map_data = None
        self.scan_data = None
        self.global_path = None
        self.local_path = None
        self.current_waypoint_idx = 0
        self.path_generated = False
        self.local_goal_idx = 0

        # Navigation parameters
        self.position_tolerance = 0.15
        self.heading_tolerance = 0.2
        self.max_linear_speed = 0.3
        self.max_angular_speed = 0.8
        self.min_obstacle_distance = 0.4

        # RRT* parameters
        self.rrt_max_iter = 300
        self.rrt_step_size = 0.3
        self.rrt_goal_sample_rate = 0.2
        self.rrt_search_radius = 1.5
        self.local_planning_distance = 3.0

        # Obstacle detection
        self.obstacle_detected = False
        self.obstacle_in_path = False
        self.replan_counter = 0

        self.get_logger().info('Task2 Bonus (RRT*) navigation node initialized.')

    def scan_callback(self, msg):
        """Process laser scan for obstacle detection."""
        self.scan_data = msg

        if self.scan_data is not None:
            ranges = np.array(self.scan_data.ranges)
            ranges[np.isinf(ranges)] = self.scan_data.range_max
            ranges[np.isnan(ranges)] = self.scan_data.range_max

            # Check front region
            front_ranges = np.concatenate([ranges[0:40], ranges[-40:]])
            min_front_distance = np.min(front_ranges)

            self.obstacle_detected = min_front_distance < self.min_obstacle_distance

            # Check if obstacle is in path
            if self.global_path and self.current_pose and self.current_waypoint_idx < len(self.global_path):
                self.obstacle_in_path = self.check_obstacle_in_path()

    def check_obstacle_in_path(self):
        """Check if there's an obstacle blocking the path ahead."""
        if self.scan_data is None or self.global_path is None:
            return False

        # Check next few waypoints
        lookahead = min(5, len(self.global_path) - self.current_waypoint_idx)

        for i in range(self.current_waypoint_idx, self.current_waypoint_idx + lookahead):
            if i >= len(self.global_path):
                break

            waypoint = self.global_path[i]
            if self.is_point_blocked(waypoint[0], waypoint[1]):
                return True

        return False

    def is_point_blocked(self, x, y):
        """Check if a point is blocked by an obstacle using laser scan."""
        if self.current_pose is None or self.scan_data is None:
            return False

        # Calculate relative position
        dx = x - self.current_pose.position.x
        dy = y - self.current_pose.position.y
        distance = math.sqrt(dx**2 + dy**2)

        if distance > 2.0:  # Only check nearby points
            return False

        # Calculate angle
        angle = math.atan2(dy, dx)
        current_yaw = self.get_yaw_from_quaternion(self.current_pose.orientation)
        relative_angle = angle - current_yaw

        # Normalize angle
        while relative_angle > math.pi:
            relative_angle -= 2 * math.pi
        while relative_angle < -math.pi:
            relative_angle += 2 * math.pi

        # Convert to scan index
        ranges = np.array(self.scan_data.ranges)
        ranges[np.isinf(ranges)] = self.scan_data.range_max
        ranges[np.isnan(ranges)] = self.scan_data.range_max

        num_scans = len(ranges)
        scan_idx = int((relative_angle / (2 * math.pi)) * num_scans)
        scan_idx = scan_idx % num_scans

        # Check if obstacle is closer than expected distance
        window = 10
        indices = [(scan_idx + i) % num_scans for i in range(-window, window + 1)]
        nearby_ranges = [ranges[i] for i in indices]

        if nearby_ranges:
            min_range = np.min(nearby_ranges)
            return min_range < (distance - 0.2)  # Obstacle blocks the point

        return False

    def map_callback(self, msg):
        """Store map data."""
        if self.map_data is None:
            self.map_data = msg
            self.get_logger().info('Map received.')

    def pose_callback(self, msg):
        """Update current pose."""
        self.current_pose = msg.pose.pose

    def goal_callback(self, msg):
        """Handle new goal."""
        self.goal_pose = msg.pose
        self.path_generated = False
        self.current_waypoint_idx = 0
        self.local_path = None
        self.get_logger().info(
            f'New goal received: ({self.goal_pose.position.x:.2f}, {self.goal_pose.position.y:.2f})'
        )

    def world_to_map(self, wx, wy):
        """Convert world to map coordinates."""
        if self.map_data is None:
            return None, None

        mx = int((wx - self.map_data.info.origin.position.x) / self.map_data.info.resolution)
        my = int((wy - self.map_data.info.origin.position.y) / self.map_data.info.resolution)

        return mx, my

    def map_to_world(self, mx, my):
        """Convert map to world coordinates."""
        if self.map_data is None:
            return None, None

        wx = mx * self.map_data.info.resolution + self.map_data.info.origin.position.x
        wy = my * self.map_data.info.resolution + self.map_data.info.origin.position.y

        return wx, wy

    def is_valid_cell(self, mx, my):
        """Check if map cell is free."""
        if self.map_data is None:
            return False

        width = self.map_data.info.width
        height = self.map_data.info.height

        if mx < 0 or mx >= width or my < 0 or my >= height:
            return False

        index = my * width + mx
        if index >= len(self.map_data.data):
            return False

        cell_value = self.map_data.data[index]
        return cell_value < 50

    def heuristic(self, a, b):
        """Euclidean distance heuristic."""
        return math.sqrt((a[0] - b[0])**2 + (a[1] - b[1])**2)

    def get_neighbors(self, node):
        """Get valid neighboring cells."""
        neighbors = []
        directions = [
            (-1, -1), (-1, 0), (-1, 1),
            (0, -1),           (0, 1),
            (1, -1),  (1, 0),  (1, 1)
        ]

        for dx, dy in directions:
            nx, ny = node[0] + dx, node[1] + dy
            if self.is_valid_cell(nx, ny):
                cost = 1.414 if abs(dx) + abs(dy) == 2 else 1.0
                neighbors.append(((nx, ny), cost))

        return neighbors

    def a_star(self, start, goal):
        """A* path planning."""
        if self.map_data is None:
            return None

        start_map = self.world_to_map(start[0], start[1])
        goal_map = self.world_to_map(goal[0], goal[1])

        if start_map[0] is None or goal_map[0] is None:
            return None

        if not self.is_valid_cell(*start_map) or not self.is_valid_cell(*goal_map):
            return None

        counter = 0
        open_set = []
        heapq.heappush(open_set, (0, counter, start_map))

        came_from = {}
        g_score = {start_map: 0}
        f_score = {start_map: self.heuristic(start_map, goal_map)}

        while open_set:
            _, _, current = heapq.heappop(open_set)

            if current == goal_map:
                path = []
                while current in came_from:
                    wx, wy = self.map_to_world(current[0], current[1])
                    path.append((wx, wy))
                    current = came_from[current]

                wx, wy = self.map_to_world(start_map[0], start_map[1])
                path.append((wx, wy))
                path.reverse()
                return path

            for neighbor, cost in self.get_neighbors(current):
                tentative_g_score = g_score[current] + cost

                if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g_score
                    f_score[neighbor] = tentative_g_score + self.heuristic(neighbor, goal_map)

                    counter += 1
                    heapq.heappush(open_set, (f_score[neighbor], counter, neighbor))

        return None

    def rrt_star(self, start, goal, max_iter=None):
        """RRT* local path replanning."""
        if max_iter is None:
            max_iter = self.rrt_max_iter

        # Initialize tree with start node
        start_node = RRTStarNode(start[0], start[1])
        nodes = [start_node]

        goal_node = None
        best_cost = float('inf')

        for i in range(max_iter):
            # Sample random point or goal
            if random.random() < self.rrt_goal_sample_rate:
                rand_x, rand_y = goal[0], goal[1]
            else:
                # Sample within local region
                rand_x = start[0] + random.uniform(-self.local_planning_distance, self.local_planning_distance)
                rand_y = start[1] + random.uniform(-self.local_planning_distance, self.local_planning_distance)

            # Find nearest node
            nearest_node = min(nodes, key=lambda n: math.sqrt((n.x - rand_x)**2 + (n.y - rand_y)**2))

            # Steer towards random point
            distance = math.sqrt((rand_x - nearest_node.x)**2 + (rand_y - nearest_node.y)**2)
            if distance > self.rrt_step_size:
                theta = math.atan2(rand_y - nearest_node.y, rand_x - nearest_node.x)
                new_x = nearest_node.x + self.rrt_step_size * math.cos(theta)
                new_y = nearest_node.y + self.rrt_step_size * math.sin(theta)
            else:
                new_x, new_y = rand_x, rand_y

            # Check if path is collision free
            if not self.is_collision_free(nearest_node.x, nearest_node.y, new_x, new_y):
                continue

            # Create new node
            new_node = RRTStarNode(new_x, new_y)

            # Find near nodes
            near_nodes = [n for n in nodes if math.sqrt((n.x - new_x)**2 + (n.y - new_y)**2) < self.rrt_search_radius]

            # Choose best parent
            min_cost = nearest_node.cost + math.sqrt((new_x - nearest_node.x)**2 + (new_y - nearest_node.y)**2)
            best_parent = nearest_node

            for near_node in near_nodes:
                cost = near_node.cost + math.sqrt((new_x - near_node.x)**2 + (new_y - near_node.y)**2)
                if cost < min_cost and self.is_collision_free(near_node.x, near_node.y, new_x, new_y):
                    min_cost = cost
                    best_parent = near_node

            new_node.parent = best_parent
            new_node.cost = min_cost
            nodes.append(new_node)

            # Rewire tree
            for near_node in near_nodes:
                new_cost = new_node.cost + math.sqrt((near_node.x - new_node.x)**2 + (near_node.y - new_node.y)**2)
                if new_cost < near_node.cost and self.is_collision_free(new_node.x, new_node.y, near_node.x, near_node.y):
                    near_node.parent = new_node
                    near_node.cost = new_cost

            # Check if goal reached
            dist_to_goal = math.sqrt((new_x - goal[0])**2 + (new_y - goal[1])**2)
            if dist_to_goal < self.rrt_step_size:
                if new_node.cost < best_cost:
                    best_cost = new_node.cost
                    goal_node = new_node

        # Extract path
        if goal_node is None:
            return None

        path = []
        node = goal_node
        while node is not None:
            path.append((node.x, node.y))
            node = node.parent

        path.reverse()
        return path

    def is_collision_free(self, x1, y1, x2, y2):
        """Check if line segment is collision free."""
        if self.map_data is None:
            return False

        # Check map for static obstacles
        steps = int(math.sqrt((x2 - x1)**2 + (y2 - y1)**2) / self.map_data.info.resolution) + 1

        for i in range(steps + 1):
            t = i / max(steps, 1)
            x = x1 + t * (x2 - x1)
            y = y1 + t * (y2 - y1)

            mx, my = self.world_to_map(x, y)
            if mx is None or not self.is_valid_cell(mx, my):
                return False

        return True

    def get_yaw_from_quaternion(self, q):
        """Extract yaw from quaternion."""
        siny_cosp = 2 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
        return math.atan2(siny_cosp, cosy_cosp)

    def navigate_to_waypoint(self, waypoint):
        """Generate velocity commands."""
        if self.current_pose is None:
            return Twist()

        dx = waypoint[0] - self.current_pose.position.x
        dy = waypoint[1] - self.current_pose.position.y
        distance = math.sqrt(dx**2 + dy**2)

        target_yaw = math.atan2(dy, dx)
        current_yaw = self.get_yaw_from_quaternion(self.current_pose.orientation)

        angle_diff = target_yaw - current_yaw
        angle_diff = math.atan2(math.sin(angle_diff), math.cos(angle_diff))

        cmd_vel = Twist()

        # Reactive obstacle avoidance
        if self.obstacle_detected and self.scan_data is not None:
            ranges = np.array(self.scan_data.ranges)
            ranges[np.isinf(ranges)] = self.scan_data.range_max
            ranges[np.isnan(ranges)] = self.scan_data.range_max

            left_clear = np.min(ranges[30:90]) > self.min_obstacle_distance
            right_clear = np.min(ranges[-90:-30]) > self.min_obstacle_distance

            cmd_vel.linear.x = self.max_linear_speed * 0.2
            if left_clear:
                cmd_vel.angular.z = self.max_angular_speed * 0.6
            elif right_clear:
                cmd_vel.angular.z = -self.max_angular_speed * 0.6
            else:
                cmd_vel.linear.x = -0.1
                cmd_vel.angular.z = self.max_angular_speed
        else:
            if abs(angle_diff) > self.heading_tolerance:
                cmd_vel.angular.z = np.clip(2.0 * angle_diff, -self.max_angular_speed, self.max_angular_speed)
                cmd_vel.linear.x = self.max_linear_speed * 0.3
            else:
                cmd_vel.linear.x = np.clip(distance * 0.8, 0.0, self.max_linear_speed)
                cmd_vel.angular.z = np.clip(angle_diff * 1.5, -self.max_angular_speed * 0.5, self.max_angular_speed * 0.5)

        return cmd_vel

    def timer_cb(self):
        """Main navigation loop with RRT* replanning."""
        if self.current_pose is None or self.goal_pose is None:
            return

        # Generate global A* path if needed
        if not self.path_generated:
            start = (self.current_pose.position.x, self.current_pose.position.y)
            goal = (self.goal_pose.position.x, self.goal_pose.position.y)

            self.get_logger().info('Planning global path with A*...')
            self.global_path = self.a_star(start, goal)

            if self.global_path is None:
                self.get_logger().error('Global path planning failed!')
                return

            self.current_waypoint_idx = 0
            self.path_generated = True

            # Publish global path
            path_msg = Path()
            path_msg.header.frame_id = 'map'
            path_msg.header.stamp = self.get_clock().now().to_msg()

            for point in self.global_path:
                pose = PoseStamped()
                pose.header.frame_id = 'map'
                pose.pose.position.x = point[0]
                pose.pose.position.y = point[1]
                path_msg.poses.append(pose)

            self.path_pub.publish(path_msg)
            self.get_logger().info(f'Global path generated with {len(self.global_path)} waypoints.')

        # Check if we need RRT* local replanning
        if self.obstacle_in_path and self.replan_counter <= 0:
            self.get_logger().info('Obstacle detected in path! Using RRT* for local replanning...')

            # Find local goal ahead on global path
            start = (self.current_pose.position.x, self.current_pose.position.y)
            local_goal_idx = min(self.current_waypoint_idx + 20, len(self.global_path) - 1)
            local_goal = self.global_path[local_goal_idx]

            # Run RRT*
            self.local_path = self.rrt_star(start, local_goal, max_iter=200)

            if self.local_path:
                self.get_logger().info(f'RRT* local path generated with {len(self.local_path)} waypoints.')
                self.local_goal_idx = local_goal_idx
                self.replan_counter = 30  # Cooldown before next replan

                # Publish local path
                path_msg = Path()
                path_msg.header.frame_id = 'map'
                path_msg.header.stamp = self.get_clock().now().to_msg()

                for point in self.local_path:
                    pose = PoseStamped()
                    pose.header.frame_id = 'map'
                    pose.pose.position.x = point[0]
                    pose.pose.position.y = point[1]
                    path_msg.poses.append(pose)

                self.local_path_pub.publish(path_msg)
            else:
                self.get_logger().warn('RRT* replanning failed!')
                self.replan_counter = 10

        self.replan_counter -= 1

        # Follow local path if available, otherwise global path
        active_path = self.local_path if self.local_path else self.global_path

        if active_path and len(active_path) > 0:
            # Find closest waypoint on path
            min_dist = float('inf')
            closest_idx = 0
            for i, wp in enumerate(active_path):
                dist = math.sqrt(
                    (wp[0] - self.current_pose.position.x)**2 +
                    (wp[1] - self.current_pose.position.y)**2
                )
                if dist < min_dist:
                    min_dist = dist
                    closest_idx = i

            # Target waypoint slightly ahead
            target_idx = min(closest_idx + 2, len(active_path) - 1)
            waypoint = active_path[target_idx]

            # Check if reached target
            dx = waypoint[0] - self.current_pose.position.x
            dy = waypoint[1] - self.current_pose.position.y
            distance = math.sqrt(dx**2 + dy**2)

            if distance < self.position_tolerance:
                if active_path is self.local_path:
                    # Reached end of local path, switch back to global
                    self.current_waypoint_idx = self.local_goal_idx
                    self.local_path = None
                    self.get_logger().info('Local path complete, resuming global path.')
                elif target_idx >= len(active_path) - 1:
                    # Reached goal
                    cmd_vel = Twist()
                    self.cmd_vel_pub.publish(cmd_vel)
                    self.get_logger().info('Goal reached!')
                    self.goal_pose = None
                    self.path_generated = False
                    return

            # Navigate
            cmd_vel = self.navigate_to_waypoint(waypoint)
            self.cmd_vel_pub.publish(cmd_vel)


def main(args=None):
    rclpy.init(args=args)

    task2_bonus = Task2Bonus()

    try:
        rclpy.spin(task2_bonus)
    except KeyboardInterrupt:
        pass
    finally:
        task2_bonus.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
