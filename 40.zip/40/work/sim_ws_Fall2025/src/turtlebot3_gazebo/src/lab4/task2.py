#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, PoseWithCovarianceStamped, Twist
from nav_msgs.msg import OccupancyGrid, Path
from sensor_msgs.msg import LaserScan
import numpy as np
import math
import heapq
from ament_index_python.packages import get_package_share_directory
import os


class Task2(Node):
    """
    Environment localization and navigation task using A* path planning.
    """
    def __init__(self):
        super().__init__('task2_node')

        # Subscribers
        self.goal_sub = self.create_subscription(
            PoseStamped, '/move_base_simple/goal', self.goal_callback, 10
        )
        self.pose_sub = self.create_subscription(
            PoseWithCovarianceStamped, '/amcl_pose', self.pose_callback, 10
        )
        self.map_sub = self.create_subscription(
            OccupancyGrid, '/map', self.map_callback, 10
        )
        self.scan_sub = self.create_subscription(
            LaserScan, '/scan', self.scan_callback, 10
        )

        # Publishers
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.path_pub = self.create_publisher(Path, '/global_plan', 10)

        # Control timer
        self.timer = self.create_timer(0.1, self.timer_cb)

        # State variables
        self.current_pose = None
        self.goal_pose = None
        self.map_data = None
        self.scan_data = None
        self.path = None
        self.current_waypoint_idx = 0
        self.path_generated = False

        # Navigation parameters
        self.position_tolerance = 0.15
        self.heading_tolerance = 0.2
        self.max_linear_speed = 0.3
        self.max_angular_speed = 0.8
        self.min_obstacle_distance = 0.3

        # Dynamic obstacle avoidance parameters
        self.obstacle_detected = False
        self.avoidance_mode = False

        self.get_logger().info('Task2 navigation node initialized.')

    def scan_callback(self, msg):
        """Process laser scan for obstacle detection."""
        self.scan_data = msg

        # Check for obstacles
        if self.scan_data is not None:
            ranges = np.array(self.scan_data.ranges)
            ranges[np.isinf(ranges)] = self.scan_data.range_max
            ranges[np.isnan(ranges)] = self.scan_data.range_max

            # Check front region for obstacles
            front_ranges = np.concatenate([ranges[0:30], ranges[-30:]])
            min_front_distance = np.min(front_ranges)

            self.obstacle_detected = min_front_distance < self.min_obstacle_distance

    def map_callback(self, msg):
        """Store map data."""
        if self.map_data is None:
            self.map_data = msg
            self.get_logger().info('Map received.')

    def pose_callback(self, msg):
        """Update current pose."""
        self.current_pose = msg.pose.pose

    def goal_callback(self, msg):
        """Handle new goal."""
        self.goal_pose = msg.pose
        self.path_generated = False
        self.current_waypoint_idx = 0
        self.get_logger().info(
            f'New goal received: ({self.goal_pose.position.x:.2f}, {self.goal_pose.position.y:.2f})'
        )

    def world_to_map(self, wx, wy):
        """Convert world coordinates to map coordinates."""
        if self.map_data is None:
            return None, None

        mx = int((wx - self.map_data.info.origin.position.x) / self.map_data.info.resolution)
        my = int((wy - self.map_data.info.origin.position.y) / self.map_data.info.resolution)

        return mx, my

    def map_to_world(self, mx, my):
        """Convert map coordinates to world coordinates."""
        if self.map_data is None:
            return None, None

        wx = mx * self.map_data.info.resolution + self.map_data.info.origin.position.x
        wy = my * self.map_data.info.resolution + self.map_data.info.origin.position.y

        return wx, wy

    def is_valid_cell(self, mx, my):
        """Check if map cell is valid and free."""
        if self.map_data is None:
            return False

        width = self.map_data.info.width
        height = self.map_data.info.height

        if mx < 0 or mx >= width or my < 0 or my >= height:
            return False

        index = my * width + mx
        if index >= len(self.map_data.data):
            return False

        # Check if cell is free (0) or unknown (-1), reject occupied (100)
        cell_value = self.map_data.data[index]
        return cell_value < 50  # Free or unknown

    def heuristic(self, a, b):
        """Euclidean distance heuristic."""
        return math.sqrt((a[0] - b[0])**2 + (a[1] - b[1])**2)

    def get_neighbors(self, node):
        """Get valid neighboring cells (8-connected)."""
        neighbors = []
        directions = [
            (-1, -1), (-1, 0), (-1, 1),
            (0, -1),           (0, 1),
            (1, -1),  (1, 0),  (1, 1)
        ]

        for dx, dy in directions:
            nx, ny = node[0] + dx, node[1] + dy
            if self.is_valid_cell(nx, ny):
                # Cost is higher for diagonal moves
                cost = 1.414 if abs(dx) + abs(dy) == 2 else 1.0
                neighbors.append(((nx, ny), cost))

        return neighbors

    def a_star(self, start, goal):
        """A* path planning algorithm."""
        if self.map_data is None:
            return None

        start_map = self.world_to_map(start[0], start[1])
        goal_map = self.world_to_map(goal[0], goal[1])

        if start_map[0] is None or goal_map[0] is None:
            return None

        if not self.is_valid_cell(*start_map) or not self.is_valid_cell(*goal_map):
            self.get_logger().warn('Start or goal is in occupied space!')
            return None

        # Priority queue: (f_score, counter, node)
        counter = 0
        open_set = []
        heapq.heappush(open_set, (0, counter, start_map))

        came_from = {}
        g_score = {start_map: 0}
        f_score = {start_map: self.heuristic(start_map, goal_map)}

        while open_set:
            _, _, current = heapq.heappop(open_set)

            if current == goal_map:
                # Reconstruct path
                path = []
                while current in came_from:
                    wx, wy = self.map_to_world(current[0], current[1])
                    path.append((wx, wy))
                    current = came_from[current]

                wx, wy = self.map_to_world(start_map[0], start_map[1])
                path.append((wx, wy))
                path.reverse()

                return path

            for neighbor, cost in self.get_neighbors(current):
                tentative_g_score = g_score[current] + cost

                if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g_score
                    f_score[neighbor] = tentative_g_score + self.heuristic(neighbor, goal_map)

                    counter += 1
                    heapq.heappush(open_set, (f_score[neighbor], counter, neighbor))

        return None  # No path found

    def simplify_path(self, path, tolerance=0.3):
        """Simplify path by removing redundant waypoints."""
        if path is None or len(path) < 3:
            return path

        simplified = [path[0]]
        for i in range(1, len(path) - 1):
            # Keep waypoint if it significantly changes direction
            prev = np.array(path[i-1])
            curr = np.array(path[i])
            next_point = np.array(path[i+1])

            v1 = curr - prev
            v2 = next_point - curr

            # Normalize
            v1_norm = v1 / (np.linalg.norm(v1) + 1e-6)
            v2_norm = v2 / (np.linalg.norm(v2) + 1e-6)

            # Keep if direction changes significantly
            dot_product = np.dot(v1_norm, v2_norm)
            if dot_product < 0.95:  # ~18 degrees
                simplified.append(path[i])

        simplified.append(path[-1])
        return simplified

    def get_yaw_from_quaternion(self, q):
        """Extract yaw from quaternion."""
        siny_cosp = 2 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
        return math.atan2(siny_cosp, cosy_cosp)

    def navigate_to_waypoint(self, waypoint):
        """Generate velocity commands to reach waypoint."""
        if self.current_pose is None:
            return Twist()

        # Calculate distance and angle to waypoint
        dx = waypoint[0] - self.current_pose.position.x
        dy = waypoint[1] - self.current_pose.position.y
        distance = math.sqrt(dx**2 + dy**2)

        target_yaw = math.atan2(dy, dx)
        current_yaw = self.get_yaw_from_quaternion(self.current_pose.orientation)

        # Angle difference
        angle_diff = target_yaw - current_yaw
        angle_diff = math.atan2(math.sin(angle_diff), math.cos(angle_diff))  # Normalize

        cmd_vel = Twist()

        # Dynamic obstacle avoidance
        if self.obstacle_detected and self.scan_data is not None:
            ranges = np.array(self.scan_data.ranges)
            ranges[np.isinf(ranges)] = self.scan_data.range_max
            ranges[np.isnan(ranges)] = self.scan_data.range_max

            left_clear = np.min(ranges[30:90]) > self.min_obstacle_distance
            right_clear = np.min(ranges[-90:-30]) > self.min_obstacle_distance

            # Avoidance maneuver
            cmd_vel.linear.x = self.max_linear_speed * 0.3
            if left_clear:
                cmd_vel.angular.z = self.max_angular_speed * 0.7
            elif right_clear:
                cmd_vel.angular.z = -self.max_angular_speed * 0.7
            else:
                cmd_vel.linear.x = -0.1  # Back up
                cmd_vel.angular.z = self.max_angular_speed

        else:
            # Normal navigation
            if abs(angle_diff) > self.heading_tolerance:
                # Rotate towards target
                cmd_vel.angular.z = np.clip(
                    2.0 * angle_diff,
                    -self.max_angular_speed,
                    self.max_angular_speed
                )
                cmd_vel.linear.x = self.max_linear_speed * 0.3

            else:
                # Move forward
                cmd_vel.linear.x = np.clip(
                    distance * 0.8,
                    0.0,
                    self.max_linear_speed
                )
                cmd_vel.angular.z = np.clip(
                    angle_diff * 1.5,
                    -self.max_angular_speed * 0.5,
                    self.max_angular_speed * 0.5
                )

        return cmd_vel

    def timer_cb(self):
        """Main navigation loop."""
        if self.current_pose is None or self.goal_pose is None:
            return

        # Generate path if needed
        if not self.path_generated:
            start = (self.current_pose.position.x, self.current_pose.position.y)
            goal = (self.goal_pose.position.x, self.goal_pose.position.y)

            self.get_logger().info('Planning path with A*...')
            raw_path = self.a_star(start, goal)

            if raw_path is None:
                self.get_logger().error('Path planning failed!')
                return

            self.path = self.simplify_path(raw_path, tolerance=0.3)
            self.current_waypoint_idx = 0
            self.path_generated = True

            # Publish path for visualization
            path_msg = Path()
            path_msg.header.frame_id = 'map'
            path_msg.header.stamp = self.get_clock().now().to_msg()

            for point in self.path:
                pose = PoseStamped()
                pose.header.frame_id = 'map'
                pose.pose.position.x = point[0]
                pose.pose.position.y = point[1]
                path_msg.poses.append(pose)

            self.path_pub.publish(path_msg)
            self.get_logger().info(f'Path generated with {len(self.path)} waypoints.')

        # Navigate along path
        if self.path and self.current_waypoint_idx < len(self.path):
            waypoint = self.path[self.current_waypoint_idx]

            # Check if reached current waypoint
            dx = waypoint[0] - self.current_pose.position.x
            dy = waypoint[1] - self.current_pose.position.y
            distance = math.sqrt(dx**2 + dy**2)

            if distance < self.position_tolerance:
                self.current_waypoint_idx += 1
                if self.current_waypoint_idx >= len(self.path):
                    # Goal reached
                    cmd_vel = Twist()
                    self.cmd_vel_pub.publish(cmd_vel)
                    self.get_logger().info('Goal reached!')
                    self.goal_pose = None
                    self.path_generated = False
                else:
                    self.get_logger().info(
                        f'Waypoint {self.current_waypoint_idx}/{len(self.path)} reached.'
                    )
            else:
                # Navigate to current waypoint
                cmd_vel = self.navigate_to_waypoint(waypoint)
                self.cmd_vel_pub.publish(cmd_vel)


def main(args=None):
    rclpy.init(args=args)

    task2 = Task2()

    try:
        rclpy.spin(task2)
    except KeyboardInterrupt:
        pass
    finally:
        task2.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
