#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, PoseWithCovarianceStamped, Twist, Point
from nav_msgs.msg import OccupancyGrid, Path
from sensor_msgs.msg import LaserScan, Image
from cv_bridge import CvBridge
import numpy as np
import math
import heapq
import cv2


class Task3(Node):
    """
    Search and localize colored balls (red, blue, green).
    Combines navigation and computer vision.
    """
    def __init__(self):
        super().__init__('task3_node')

        # Subscribers
        self.pose_sub = self.create_subscription(
            PoseWithCovarianceStamped, '/amcl_pose', self.pose_callback, 10
        )
        self.map_sub = self.create_subscription(
            OccupancyGrid, '/map', self.map_callback, 10
        )
        self.scan_sub = self.create_subscription(
            LaserScan, '/scan', self.scan_callback, 10
        )
        self.camera_sub = self.create_subscription(
            Image, '/camera/image_raw', self.camera_callback, 10
        )

        # Publishers
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.path_pub = self.create_publisher(Path, '/global_plan', 10)

        # Ball position publishers
        self.red_pos_pub = self.create_publisher(Point, '/red_pos', 10)
        self.blue_pos_pub = self.create_publisher(Point, '/blue_pos', 10)
        self.green_pos_pub = self.create_publisher(Point, '/green_pos', 10)

        # Control timer
        self.timer = self.create_timer(0.1, self.timer_cb)

        # CV Bridge
        self.bridge = CvBridge()

        # State variables
        self.current_pose = None
        self.map_data = None
        self.scan_data = None
        self.current_image = None

        # Ball detection state
        self.balls_found = {
            'red': None,
            'blue': None,
            'green': None
        }
        self.balls_published = set()

        # Navigation state
        self.search_waypoints = []
        self.current_waypoint_idx = 0
        self.waypoints_generated = False

        # Navigation parameters
        self.position_tolerance = 0.2
        self.heading_tolerance = 0.2
        self.max_linear_speed = 0.25
        self.max_angular_speed = 0.6
        self.min_obstacle_distance = 0.35

        # Search parameters
        self.search_mode = 'systematic'  # 'systematic' or 'complete'
        self.rotation_count = 0

        self.get_logger().info('Task3 search and localize node initialized.')

    def camera_callback(self, msg):
        """Process camera images."""
        try:
            self.current_image = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        except Exception as e:
            self.get_logger().error(f'CV Bridge error: {e}')

    def scan_callback(self, msg):
        """Process laser scan data."""
        self.scan_data = msg

    def map_callback(self, msg):
        """Store map data."""
        if self.map_data is None:
            self.map_data = msg
            self.get_logger().info('Map received.')

    def pose_callback(self, msg):
        """Update current pose."""
        self.current_pose = msg.pose.pose

    def detect_ball(self, image):
        """Detect colored balls in the image."""
        if image is None:
            return {}

        # Convert to HSV for better color detection
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

        # Define color ranges in HSV
        color_ranges = {
            'red': [
                (np.array([0, 120, 70]), np.array([10, 255, 255])),
                (np.array([170, 120, 70]), np.array([180, 255, 255]))
            ],
            'blue': [(np.array([100, 150, 50]), np.array([130, 255, 255]))],
            'green': [(np.array([40, 40, 40]), np.array([80, 255, 255]))]
        }

        detected_balls = {}

        for color, ranges in color_ranges.items():
            mask = np.zeros(hsv.shape[:2], dtype=np.uint8)

            # Combine multiple ranges for red (wraps around in HSV)
            for lower, upper in ranges:
                mask = cv2.bitwise_or(mask, cv2.inRange(hsv, lower, upper))

            # Morphological operations to clean up
            kernel = np.ones((5, 5), np.uint8)
            mask = cv2.erode(mask, kernel, iterations=1)
            mask = cv2.dilate(mask, kernel, iterations=2)

            # Find contours
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            if contours:
                # Get largest contour
                largest_contour = max(contours, key=cv2.contourArea)
                area = cv2.contourArea(largest_contour)

                # Filter by minimum area
                if area > 500:  # Minimum area threshold
                    M = cv2.moments(largest_contour)
                    if M['m00'] > 0:
                        cx = int(M['m10'] / M['m00'])
                        cy = int(M['m01'] / M['m00'])

                        detected_balls[color] = {
                            'center': (cx, cy),
                            'area': area,
                            'contour': largest_contour
                        }

        return detected_balls

    def estimate_ball_position(self, image_x, image_y, image_width, image_height):
        """Estimate ball position in world coordinates using camera geometry."""
        if self.current_pose is None or self.scan_data is None:
            return None

        # Camera parameters (approximate for TurtleBot3)
        horizontal_fov = 62.0 * math.pi / 180.0  # radians

        # Calculate angle to ball relative to robot
        center_x = image_width / 2
        pixel_offset = image_x - center_x
        angle_to_ball = (pixel_offset / image_width) * horizontal_fov

        # Get current robot orientation
        current_yaw = self.get_yaw_from_quaternion(self.current_pose.orientation)

        # Absolute angle to ball
        ball_angle = current_yaw + angle_to_ball

        # Estimate distance using laser scan
        # Convert angle to laser scan index
        ranges = np.array(self.scan_data.ranges)
        ranges[np.isinf(ranges)] = self.scan_data.range_max
        ranges[np.isnan(ranges)] = self.scan_data.range_max

        # Calculate scan index for ball angle
        num_scans = len(ranges)
        scan_angle = angle_to_ball

        # Normalize scan angle to [-pi, pi]
        while scan_angle > math.pi:
            scan_angle -= 2 * math.pi
        while scan_angle < -math.pi:
            scan_angle += 2 * math.pi

        # Convert to scan index (assuming 360 degree scan)
        scan_idx = int((scan_angle / (2 * math.pi)) * num_scans)
        scan_idx = scan_idx % num_scans

        # Get distance from laser scan (with some averaging)
        window = 5
        indices = [(scan_idx + i) % num_scans for i in range(-window, window + 1)]
        distances = [ranges[i] for i in indices if ranges[i] < self.scan_data.range_max - 0.1]

        if distances:
            distance = np.median(distances)
        else:
            distance = 1.5  # Default distance if no valid scan

        # Calculate ball position in world frame
        ball_x = self.current_pose.position.x + distance * math.cos(ball_angle)
        ball_y = self.current_pose.position.y + distance * math.sin(ball_angle)

        return (ball_x, ball_y)

    def generate_search_waypoints(self):
        """Generate waypoints for systematic room search."""
        if self.map_data is None:
            return []

        waypoints = []

        # Sample points across the map in a grid pattern
        resolution = self.map_data.info.resolution
        width = self.map_data.info.width
        height = self.map_data.info.height
        origin_x = self.map_data.info.origin.position.x
        origin_y = self.map_data.info.origin.position.y

        # Create grid of points
        step = 40  # Grid spacing in cells

        for mx in range(step // 2, width, step):
            for my in range(step // 2, height, step):
                if self.is_valid_cell(mx, my):
                    wx = mx * resolution + origin_x
                    wy = my * resolution + origin_y
                    waypoints.append((wx, wy))

        return waypoints

    def get_yaw_from_quaternion(self, q):
        """Extract yaw from quaternion."""
        siny_cosp = 2 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
        return math.atan2(siny_cosp, cosy_cosp)

    def world_to_map(self, wx, wy):
        """Convert world coordinates to map coordinates."""
        if self.map_data is None:
            return None, None

        mx = int((wx - self.map_data.info.origin.position.x) / self.map_data.info.resolution)
        my = int((wy - self.map_data.info.origin.position.y) / self.map_data.info.resolution)

        return mx, my

    def is_valid_cell(self, mx, my):
        """Check if map cell is valid and free."""
        if self.map_data is None:
            return False

        width = self.map_data.info.width
        height = self.map_data.info.height

        if mx < 0 or mx >= width or my < 0 or my >= height:
            return False

        index = my * width + mx
        if index >= len(self.map_data.data):
            return False

        cell_value = self.map_data.data[index]
        return cell_value < 50

    def navigate_to_waypoint(self, waypoint):
        """Generate velocity commands to reach waypoint."""
        if self.current_pose is None:
            return Twist()

        dx = waypoint[0] - self.current_pose.position.x
        dy = waypoint[1] - self.current_pose.position.y
        distance = math.sqrt(dx**2 + dy**2)

        target_yaw = math.atan2(dy, dx)
        current_yaw = self.get_yaw_from_quaternion(self.current_pose.orientation)

        angle_diff = target_yaw - current_yaw
        angle_diff = math.atan2(math.sin(angle_diff), math.cos(angle_diff))

        cmd_vel = Twist()

        # Check for obstacles
        if self.scan_data is not None:
            ranges = np.array(self.scan_data.ranges)
            ranges[np.isinf(ranges)] = self.scan_data.range_max
            ranges[np.isnan(ranges)] = self.scan_data.range_max

            front_ranges = np.concatenate([ranges[0:30], ranges[-30:]])
            min_front_distance = np.min(front_ranges)

            if min_front_distance < self.min_obstacle_distance:
                # Obstacle avoidance
                left_clear = np.min(ranges[30:90]) > self.min_obstacle_distance
                right_clear = np.min(ranges[-90:-30]) > self.min_obstacle_distance

                cmd_vel.linear.x = 0.1
                if left_clear:
                    cmd_vel.angular.z = self.max_angular_speed * 0.5
                elif right_clear:
                    cmd_vel.angular.z = -self.max_angular_speed * 0.5
                else:
                    cmd_vel.linear.x = -0.1
                    cmd_vel.angular.z = self.max_angular_speed
                return cmd_vel

        # Normal navigation
        if abs(angle_diff) > self.heading_tolerance:
            cmd_vel.angular.z = np.clip(
                2.0 * angle_diff,
                -self.max_angular_speed,
                self.max_angular_speed
            )
            cmd_vel.linear.x = self.max_linear_speed * 0.3
        else:
            cmd_vel.linear.x = np.clip(
                distance * 0.5,
                0.0,
                self.max_linear_speed
            )
            cmd_vel.angular.z = np.clip(
                angle_diff * 1.0,
                -self.max_angular_speed * 0.3,
                self.max_angular_speed * 0.3
            )

        return cmd_vel

    def timer_cb(self):
        """Main search and localize loop."""
        if self.current_pose is None:
            return

        # Process camera image to detect balls
        if self.current_image is not None:
            detected = self.detect_ball(self.current_image)

            for color, info in detected.items():
                if color not in self.balls_published:
                    # Estimate ball position
                    h, w = self.current_image.shape[:2]
                    cx, cy = info['center']

                    ball_pos = self.estimate_ball_position(cx, cy, w, h)

                    if ball_pos is not None:
                        self.balls_found[color] = ball_pos

                        # Publish ball position
                        point = Point()
                        point.x = ball_pos[0]
                        point.y = ball_pos[1]
                        point.z = 0.0

                        if color == 'red':
                            self.red_pos_pub.publish(point)
                        elif color == 'blue':
                            self.blue_pos_pub.publish(point)
                        elif color == 'green':
                            self.green_pos_pub.publish(point)

                        self.balls_published.add(color)
                        self.get_logger().info(
                            f'{color.capitalize()} ball found at ({ball_pos[0]:.2f}, {ball_pos[1]:.2f})'
                        )

        # Check if all balls found
        if len(self.balls_published) >= 3:
            # Stop robot
            cmd_vel = Twist()
            self.cmd_vel_pub.publish(cmd_vel)
            self.get_logger().info('All balls found! Task complete.')
            return

        # Generate search waypoints if not done
        if not self.waypoints_generated:
            self.search_waypoints = self.generate_search_waypoints()
            self.waypoints_generated = True
            self.get_logger().info(f'Generated {len(self.search_waypoints)} search waypoints.')

        # Navigate to search waypoints
        if self.current_waypoint_idx < len(self.search_waypoints):
            waypoint = self.search_waypoints[self.current_waypoint_idx]

            dx = waypoint[0] - self.current_pose.position.x
            dy = waypoint[1] - self.current_pose.position.y
            distance = math.sqrt(dx**2 + dy**2)

            if distance < self.position_tolerance:
                # Reached waypoint, do a rotation to scan
                if self.rotation_count < 8:  # Rotate 360 degrees in 8 steps
                    cmd_vel = Twist()
                    cmd_vel.angular.z = self.max_angular_speed * 0.5
                    self.cmd_vel_pub.publish(cmd_vel)
                    self.rotation_count += 1
                else:
                    # Move to next waypoint
                    self.current_waypoint_idx += 1
                    self.rotation_count = 0
                    self.get_logger().info(
                        f'Waypoint {self.current_waypoint_idx}/{len(self.search_waypoints)} completed.'
                    )
            else:
                # Navigate to waypoint
                cmd_vel = self.navigate_to_waypoint(waypoint)
                self.cmd_vel_pub.publish(cmd_vel)
                self.rotation_count = 0

        else:
            # All waypoints visited, continue rotating
            cmd_vel = Twist()
            cmd_vel.angular.z = self.max_angular_speed * 0.3
            self.cmd_vel_pub.publish(cmd_vel)


def main(args=None):
    rclpy.init(args=args)

    task3 = Task3()

    try:
        rclpy.spin(task3)
    except KeyboardInterrupt:
        pass
    finally:
        task3.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
