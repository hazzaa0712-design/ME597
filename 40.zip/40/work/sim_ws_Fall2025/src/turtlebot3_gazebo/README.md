# turtlebot3_gazebo
Formerly `ME597-Fall2024-tb3-gz`

### Launch house
`ros2 launch turtlebot3_gazebo turtlebot3_house_norviz.launch.py`

### Launch house & Red Ball (Lab 4 - Task 6)
`ros2 launch turtlebot3_gazebo task_6.launch.py`
