# sim_utils

### Lab 3: Control Red Ball
`ros2 run sim_utils red_ball_controller`

Use wasd keys.